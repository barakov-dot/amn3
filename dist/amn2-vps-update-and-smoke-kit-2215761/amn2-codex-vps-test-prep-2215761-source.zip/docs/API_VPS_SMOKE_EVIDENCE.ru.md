# API VPS Smoke Evidence

Дата: 2026-06-02. Обновлено: 2026-06-07.

Назначение: зафиксировать только безопасные факты реального VPS smoke для read-only API shell на ветке `codex/read-only-api-route-shell`.

Template policy: Заполнять после реального VPS smoke; current command marker `python -m app.cli api smoke-cycle`; historical filled evidence ниже оставляет только safe summary.

Не вставлять raw API token, Authorization header, token hash, `.conf`, QR, `vpn://`, `PrivateKey`, `PresharedKey`, SSH password/private key, `.env`, PSK, полные response bodies или `api-server.log` без ручной redaction.

## c92bd1a Source Overlay Alignment: 2026-06-07

Назначение: зафиксировать safe summary выравнивания production source overlay `/opt/amn2` до `c92bd1a`. На текущем VPS постоянный systemd service намеренно не запускается: этот сервер используется для ручной проверки, а service deployment переносится на другой целевой сервер.

Source update evidence:

```text
workspace: /opt/amn2
kit_checksum: OK
source_checksum: OK
source_update_status: passed
target: /opt/amn2
source_commit: c92bd1a
source_overlay_commit: c92bd1a
safe_log_dir: /opt/amn2/vps-smoke/source-update-20260607T194406Z
runtime_preserved: data/.env/servers.yml/venv present
VPS_APPLY_ENABLED: false
```

Backup evidence:

```text
APP_SECRET_KEY: present, value not published
backup_create: passed
backup_file: backups/amneziya-backup-20260607T195439Z.tar.enc
backup_verify: passed
backup_manifest_app: amneziya
backup_manifest_format_version: 1
backup_manifest_includes: database, manifest
backup_manifest_excludes: app_secret_key, telegram_bot_token, qr_files, plain_configs
backup_database_checksum_sha256: aacad1ee5fb60906bb9d2895ea82f6f7404a6b6752a1dd1bc7e1787c61a82f64
dotenv_shell_source_status: failed-on-special-character
dotenv_safe_loader_next_step: use python-dotenv for APP_SECRET_KEY only
```

Preflight evidence:

```text
bot_check_network: ok
bot_identity: ok
proxy: enabled
server_config: ok
database_sync: ok
server_check_dry_run: ok
peer_apply_dry_run: ok
peer_revoke_dry_run: ok
traffic_dry_run: ok
backup_target: ok
```

Read-only API smoke evidence:

```text
api_bind: http://127.0.0.1:3040
api_smoke_status: passed
api_checked_routes: 6
route_status_codes: 200
forbidden_markers: []
token_raw_display: hidden
token_lifecycle: revoked
```

Manual web evidence:

```text
WEB_ADMIN_HOST: 127.0.0.1
WEB_ADMIN_SESSION_COOKIE_SECURE: true
old_manual_web_pid: 2333887, stopped
diagnostic_web_pid: 2990245
startup_tick: 5
startup_log: Application startup complete
web_login_http: 200
web_listener: 127.0.0.1:3030
web_listener_after_cleanup: stopped
systemd_launch_status: deferred-working-server
```

VPS verdict:

```text
decision: c92bd1a-manual-prelaunch-pass-systemd-deferred
web_systemd_launch_status: deferred-working-server
manual_web_runtime_status: passed
write_routes_enabled: false
write_operations_enabled: false
next_step: repeat gate on future working server, then enable systemd/reverse proxy there
```

## Production Launch Gate Attempt: 2026-06-07 / 42ffa65

Назначение: зафиксировать safe summary production launch проверки, которую оператор выполнил на фактически работающем `/opt/amn2`. Важно: вывод VPS показал `source_overlay_commit: 42ffa65`, а текущий локальный gate target после соседнего чата уже `c92bd1a`. Поэтому эта запись подтверждает работоспособность текущего observed runtime, но не объявляет `c92bd1a` полностью пройденным на этом VPS.

Runtime evidence:

```text
workspace: /opt/amn2
source_overlay_commit: 42ffa65
current_gate_target: c92bd1a
c92bd1a_alignment_status: pending
data_dir: present
env_file: present
servers_yml: present
venv: present
VPS_APPLY_ENABLED: false
APP_SECRET_KEY: present, value not published
```

Backup evidence:

```text
backup_create: passed
backup_file: backups/amneziya-backup-20260607T192423Z.tar.enc
backup_verify: passed
backup_manifest_app: amneziya
backup_manifest_format_version: 1
backup_manifest_includes: database, manifest
backup_manifest_excludes: app_secret_key, telegram_bot_token, qr_files, plain_configs
```

Preflight evidence:

```text
bot_check_network: ok
bot_identity: ok
proxy: enabled
server_config: ok
database_sync: ok
server_check_dry_run: ok
peer_apply_dry_run: ok
peer_revoke_dry_run: ok
traffic_dry_run: ok
backup_target: ok
```

Read-only API smoke evidence:

```text
api_bind: http://127.0.0.1:3040
api_smoke_status: passed
api_checked_routes: 6
route_status_codes: 200
forbidden_markers: []
token_raw_display: hidden
token_lifecycle: revoked
```

Web/admin and listener evidence:

```text
web_login_http: 200
web_listener: 127.0.0.1:3030
api_listener: 127.0.0.1:3040
public_api_3040: no
direct_public_web_3030: no evidence claimed
```

VPS verdict:

```text
decision_for_observed_runtime: launch-gate-checks-pass-for-42ffa65
decision_for_current_c92_gate: pending-source-overlay-alignment
next_step: apply or confirm c92bd1a source overlay, then repeat short backup/smoke/listener gate
write_routes_enabled: false
write_operations_enabled: false
```

## Source Overlay Promotion: 2026-06-07 / c92bd1a

Назначение: зафиксировать safe summary фактического promotion `/opt/amn2` до source overlay `c92bd1a Bind web admin systemd to loopback` и повторного read-only smoke уже на production source overlay path.

Source update evidence:

```text
Дата и время update: 2026-06-07 18:21 UTC
workspace: /opt/amn2
source overlay before: 42ffa65
source overlay after: c92bd1a
source_update_status: passed
source_update_run_id: 20260607T182118Z
source_sha: 272CC013A416937AAA2256A1643B2C77F707874D28FDCB2EA16534E349DD4FC2
safe_log_dir: /opt/amn2/vps-smoke/source-update-20260607T182118Z
runtime preserved: .env, data/, venv/, servers.yml
VPS_APPLY_ENABLED: false
```

Read-only smoke evidence:

```text
Дата и время smoke: 2026-06-07 18:21 UTC
workspace: /opt/amn2
API bind: http://127.0.0.1:3040
Server name: local
branch/head: not a git checkout
preflight_status: skipped
server_db_sync_status: passed
api_ready_status: passed
api_smoke_status: passed
auth_status: passed
missing_bearer_http: 401
wrong_scope_http: 403
revoked_token_http: 401
listener_status: passed
audit_status: passed
safe_evidence_dir: /opt/amn2/vps-smoke/api-loopback-20260607T182131Z
safe_bundle: /opt/amn2/vps-smoke/api-loopback-safe-evidence-20260607T182131Z.tar.gz
```

Web/admin loopback evidence:

```text
systemd template ExecStart: /opt/amn2/venv/bin/python -m app.cli web serve --host 127.0.0.1 --port 3030
web/admin access path: approved HTTPS reverse proxy
direct public web/admin 3030: blocked unless separate gate
public API 3040 exposure: blocked
```

VPS verdict:

```text
decision: read-only-vps-smoke-pass-c92bd1a
current source overlay: c92bd1a
write_routes_enabled: false
write_operations_enabled: false
controlled production next gate: operator-only web/admin and bot launch checklist
```

## Source Overlay Promotion: 2026-06-07 / 42ffa65

Назначение: зафиксировать safe summary фактического promotion `/opt/amn2` до source overlay `42ffa65 Record git checkout smoke status` и повторного read-only smoke уже на production source overlay path.

Source update evidence:

```text
Дата и время update: 2026-06-07 15:08 UTC
workspace: /opt/amn2
source overlay before: c8a6363
source overlay after: 42ffa65
source_update_status: passed
safe_log_dir: /opt/amn2/vps-smoke/source-update-20260607T150818Z
data/: preserved
.env: preserved
servers.yml: preserved
venv/: preserved
VPS_APPLY_ENABLED: false
```

Read-only route evidence:

```text
Дата и время smoke: 2026-06-07 15:09 UTC
workspace: /opt/amn2
API bind: http://127.0.0.1:3040
Server name: local
Smoke command: python -m app.cli api smoke-cycle
checked_routes: 6
status: passed

servers: 200, forbidden_markers=[]
integration_status: 200, forbidden_markers=[]
local_agent_runtime_summary: 200, forbidden_markers=[]
server_summary: 200, forbidden_markers=[]
metrics_summary: 200, forbidden_markers=[]
users_summary: 200, forbidden_markers=[]
```

Token evidence:

```text
smoke token status: revoked
smoke token revoke reason: smoke-complete
raw token display: hidden
raw token/header/hash evidence: not published
```

VPS verdict:

```text
api_smoke_status: passed
forbidden_markers: none
listener_scope: loopback target
write_routes_enabled: false
write_operations_enabled: false
controlled_prod_decision_at_time: controlled-prod-ready for source overlay 42ffa65
superseded_by_source_overlay: c92bd1a
next gate after c92bd1a smoke: controlled production launch checklist
```

## Git Checkout Smoke: 2026-06-06 / 62ff184 read-only gate

Назначение: зафиксировать safe summary фактического VPS smoke для текущего read-only head `62ff184 Update controlled prod status visibility` на git-managed checkout `/opt/amn2-git`.

```text
Дата и время проверки: 2026-06-06 21:41 UTC
VPS alias: mirror / local
Workspace: /opt/amn2-git
Branch: codex-vps-test-prep
Target read-only gate head: 62ff184 Update controlled prod status visibility
API bind: http://127.0.0.1:3040
Server name: local
Smoke command: python -m app.cli api smoke-cycle
```

Read-only route evidence:

```text
checked_routes: 6
status: passed

servers: 200, forbidden_markers=[]
integration_status: 200, forbidden_markers=[]
local_agent_runtime_summary: 200, forbidden_markers=[]
server_summary: 200, forbidden_markers=[]
metrics_summary: 200, forbidden_markers=[]
users_summary: 200, forbidden_markers=[]
```

Token evidence:

```text
smoke token status: revoked
smoke token revoke reason: smoke-complete
raw token display: hidden
raw token/header/hash evidence: not published
```

VPS verdict:

```text
api_smoke_status: passed
forbidden_markers: none
listener_scope: loopback target
write_routes_enabled: false
write_operations_enabled: false
decision: 62ff184 read-only git-checkout VPS smoke passed
source_overlay_promotion: not claimed by this evidence
```

## Controlled Prod Update: 2026-06-07 / c8a6363 source overlay

Назначение: зафиксировать safe summary фактического VPS состояния после source overlay update и loopback API smoke на `/opt/amn2`.

```text
source overlay commit: c8a6363
source update run_id: 20260606T202012Z
source_update_status: passed
api loopback smoke run_id: 20260606T202040Z
workspace: /opt/amn2
VPS checkout state: not a git checkout; source-overlay/update kit path
API bind: http://127.0.0.1:3040
VPS_APPLY_ENABLED shell: false
VPS_APPLY_ENABLED .env: false
server name: local
runtime: docker
```

Read-only route evidence:

```text
checked_routes: 5
status: passed

servers: 200, forbidden_markers=[]
integration_status: 200, forbidden_markers=[]
server_summary: 200, forbidden_markers=[]
metrics_summary: 200, forbidden_markers=[]
users_summary: 200, forbidden_markers=[]
```

Auth/listener/audit evidence:

```text
auth_status: passed
missing_bearer_actual: 401
wrong_scope_actual: 403
revoked_token_actual: 401
listener_status: passed
api_listener: 127.0.0.1:3040 loopback-only
audit_status: passed
api_read_rows: 5
audit_safe: yes
server_db_sync: passed
```

Access and recovery boundary:

```text
web/admin access: HTTPS reverse proxy approved by operator
public API 3040 exposure: blocked
data/: preserved
.env: preserved
servers.yml: preserved
recovery kits: 32d01fd and c8a6363 present with sha files and extracted dirs
controlled_prod_decision: controlled-prod-ready for source overlay c8a6363
superseded by source overlay: 42ffa65
next runbook: docs/AMN2_VPS_SMOKE_62FF184_RUNBOOK.ru.md
```

## 0. Актуальный Smoke: 2026-06-06 / 64a6750

Назначение: зафиксировать безопасный факт read-only API smoke на git-managed checkout `/opt/amn2-git` после перехода с source overlay `/opt/amn2`.

```text
Дата и время проверки: 2026-06-06, около 20:48 UTC
VPS alias: mirror / local
Workspace: /opt/amn2-git
Branch: codex-vps-test-prep
Target app-code commit: 64a6750 Document controlled prod readiness
API bind: http://127.0.0.1:3040
VPS_APPLY_ENABLED: false
Server name: local
```

Preflight evidence:

```text
Telegram API: ok
Bot identity: ok
Proxy: enabled
server config: ok
database sync: ok
server check dry-run: ok
peer apply dry-run: ok
peer revoke dry-run: ok
traffic dry-run: ok
backup target: ok
```

Read-only route evidence:

```text
checked_routes: 5
status: passed

servers: 200, forbidden_markers=[]
integration_status: 200, forbidden_markers=[]
server_summary: 200, forbidden_markers=[]
metrics_summary: 200, forbidden_markers=[]
users_summary: 200, forbidden_markers=[]
```

Token evidence:

```text
new smoke token status: revoked
new smoke token revoke reason: smoke-complete
raw token/header/hash evidence: not published
previous chat-exposed token: not revoked by operator decision
previous chat-exposed token expiry reported by CLI: 2026-06-13T20:37:39+00:00
```

VPS verdict:

```text
api_smoke_status: passed
forbidden_markers: none
listener_scope: loopback-only
write_routes_enabled: false
write_operations_enabled: false
controlled_prod_decision: defer-prod
defer reason: previous chat-exposed token remains a token-hygiene exception until revoked or expired
```

This run confirms the read-only API route shell on the current app-code baseline. It does not grant public exposure, write API routes, `config:read`, Local Agent mutations, backup/import/reboot routes or broad live peer mutation permission.

Follow-up local route after this evidence:

```text
route: GET /api/local-agent/runtime/summary
scope: server:read
status: local-ready, not included in the 2026-06-06 VPS smoke above
next VPS smoke expectation: checked_routes=6
next VPS smoke command: python -m app.cli api smoke-cycle
secret boundary: no Local Agent host/port/token id/token hash/container/interface/config path
```

## 1. Контекст

```text
Дата и время проверки: 2026-06-02, run_id=20260602T171639Z
VPS alias: mirror / local
Workspace: /opt/amn2
Branch: codex/read-only-api-route-shell
Commit: 2010d60 Add API VPS smoke evidence template
VPS checkout state: not a git checkout; source-overlay/update kit path
API bind: http://127.0.0.1:3040
Smoke script version: 2026-06-02.2
Smoke script sha256: 6ebe5c50d634541dd1a8fb1bac269e2593deae335e3d75f40a4d589a48a33743
VPS_APPLY_ENABLED: false
Safe evidence dir: /opt/amn2/vps-smoke/api-loopback-20260602T171639Z
Safe bundle: /opt/amn2/vps-smoke/api-loopback-safe-evidence-20260602T171639Z.tar.gz
```

## 2. Route Evidence

Фактические aggregate counts и response bodies не копировались в чат/документ, чтобы не расширять evidence beyond safe summary. Smoke script выполнил route-level read-only проверку через scoped token.

```text
api_ready_status: passed
api_smoke_status: passed
```

Read-only API shell scope:

```text
GET /api/servers
GET /api/servers/{server_name}/summary
GET /api/metrics/summary
GET /api/users/summary
```

Forbidden data boundary:

```text
raw token/header/hash/config/key/PSK evidence: not published
full response bodies: not published
```

## 3. Auth And Scope Evidence

```text
auth_status: passed

Missing bearer token:
  expected HTTP: 401
  actual HTTP: 401

Wrong scope:
  expected HTTP: 403
  actual HTTP: 403

Revoked token after smoke:
  expected HTTP: 401
  actual HTTP: 401
```

## 4. Audit Evidence

```text
audit_status: passed
api_read rows present: verified by smoke script
metadata secret boundary: raw token/header/hash/config/key/PSK not published
```

`api-server.log` was not copied into AMN3 and must not be shared unless manually redacted.

## 5. Network Exposure Evidence

```text
API bind: http://127.0.0.1:3040
listener_status: passed
```

API остается loopback-only (`127.0.0.1`) до отдельного решения о reverse proxy, TLS, rate-limit и production auth boundary.

## 6. VPS Verdict

```text
VPS verdict: pass
run_id: 20260602T171639Z
preflight_status: passed
api_ready_status: passed
api_smoke_status: passed
auth_status: passed
missing_bearer_http: 401
wrong_scope_http: 403
revoked_token_http: 401
listener_status: passed
audit_status: passed
```

Next local action:

```text
PR/merge decision for codex/read-only-api-route-shell back into codex-vps-test-prep.
```

Next VPS action:

```text
No additional VPS action for this read-only aggregate API shell unless a merge/retest policy explicitly requires it.
```

## 7. Still Blocked Until Separate Gates

- `/api/clients` write CRUD;
- API `config:read`;
- public/self-service config delivery;
- backup/import/reboot;
- SSH/sync/config/runtime-changing routes;
- public unauthenticated `/docs` or `/metrics`.
