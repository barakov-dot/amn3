from __future__ import annotations

import subprocess
from pathlib import Path

from app.db.connection import connect
from app.db.repositories import Repository
from app.db.schema import initialize_schema
from app.services.integration_status import build_integration_status


FORBIDDEN_MARKERS = [
    "PrivateKey",
    "PresharedKey",
    "Authorization",
    "token_hash",
    "vpn://",
    ".conf",
    "root@",
    "docker exec",
    "awg show",
]


def test_build_integration_status_reports_controlled_prod_without_write_enablement(tmp_path: Path):
    db_path = tmp_path / "amneziya.sqlite3"
    conn = connect(db_path)
    try:
        initialize_schema(conn)
        repo = Repository(conn)
        _seed_server(repo)

        report = build_integration_status(repo)
    finally:
        conn.close()

    assert report["status"] == "phase_6_productization_planning"
    expected_head = _expected_git_head()
    assert report["source_checkpoint"] == {
        "current_branch_head": expected_head,
        "latest_vps_smoked_package_head": "b3102db",
        "latest_vps_smoke_status": "live_update_smoke_pass",
        "package_status_for_branch_head": "not_package_rebuilt_not_vps_smoked",
        "public_self_service_open": False,
        "vps_apply_enabled_default": False,
    }
    assert report["api_baseline"]["status"] == "p7_scoped_write_contour_ready"
    assert report["api_baseline"]["stable_head"] == expected_head
    assert report["api_baseline"]["previous_stable_head"] == "b3102db"
    assert report["api_baseline"]["api_web_baseline_head"] == expected_head
    assert report["api_baseline"]["integration_status_head"] == expected_head
    assert report["api_baseline"]["allowed_scopes"] == [
        "install:write",
        "metrics:read",
        "server:read",
    ]
    assert report["api_baseline"]["write_routes_enabled"] is True
    assert report["api_baseline"]["write_route_count"] == 1
    assert (
        report["api_baseline"]["write_route_boundary"]
        == "install-mutation-request-audit-only"
    )
    assert report["api_baseline"]["public_api_exposed"] is False
    assert report["remote_operation_gate"]["candidate_head"] == "7281254"
    assert report["remote_operation_gate"]["stable_merge_head"] == "708c98e"
    assert report["remote_operation_gate"]["phase_1"] == "dry_run_only_pass"
    assert report["remote_operation_gate"]["phase_2"] == "verified_live"
    assert report["remote_operation_gate"]["write_operations_enabled"] is False
    assert report["controlled_prod_readiness"]["status"] == "operator_only_pilot_accepted"
    assert report["controlled_prod_readiness"]["decision"] == "operator-only-pilot-accepted"
    assert report["controlled_prod_readiness"]["runbook"] == "docs/ROUTE_AUTH_OPERATION_POLICY.ru.md"
    assert report["controlled_prod_readiness"]["source_overlay_head"] == "b3102db"
    assert report["controlled_prod_readiness"]["vps_smoke_run_id"] == "20260613T154826Z"
    assert report["controlled_prod_readiness"]["source_update_run_id"] == "20260613T154511Z"
    assert report["controlled_prod_readiness"]["web_admin_access"] == "ssh_tunnel_loopback"
    assert report["controlled_prod_readiness"]["manual_web_check"] == "passed"
    assert report["controlled_prod_readiness"]["service_deployment"] == "active_on_disposable_test_vps"
    assert report["controlled_prod_readiness"]["api_listener"] == "absent_or_loopback_only"
    assert report["controlled_prod_readiness"]["vps_apply_enabled_default"] is False
    assert report["local_read_only_extension"]["head"] == expected_head
    assert report["local_read_only_extension"]["status"] == "local_only_not_vps_smoked"
    assert report["local_read_only_extension"]["vps_smoke_status"] == "not_run_for_branch_head"
    assert report["local_read_only_extension"]["checked_routes"] == 6
    assert report["local_read_only_extension"]["workspace"] == "local_branch"
    assert report["local_read_only_extension"]["token_lifecycle"] == "revoked"
    assert report["aggregate_state"]["servers"] == 1
    assert report["capability_registry"]["status"] == "policy_registry_ready"
    assert report["capability_registry"]["current_branch_head"] == expected_head
    assert report["capability_registry"]["latest_vps_smoked_package_head"] == "b3102db"
    assert report["capability_registry"]["server_capabilities"] == [
        {
            "capability": "single_server_operator_control",
            "status": "implemented_operator_only",
            "runtime": "docker",
            "protocol": "amneziawg",
            "safe_surfaces": [
                "web_admin_operator_only",
                "read_only_api_aggregate",
                "bot_access_flow",
            ],
        }
    ]
    assert report["capability_registry"]["future_protocols"] == [
        {
            "protocol": "wireguard",
            "status": "blocked_future",
            "gate": "P6-M001 implementation gate",
            "license_boundary": "no upstream code copy",
        },
        {
            "protocol": "xray",
            "status": "blocked_future",
            "gate": "P6-M001 implementation gate",
            "license_boundary": "no upstream code copy",
        },
    ]
    conflict_model = report["capability_registry"]["multi_instance_conflict_model"]
    assert conflict_model["status"] == "local_conflict_model_ready"
    assert conflict_model["gate"] == "local-only/docs/tests"
    assert conflict_model["live_multi_instance_apply_allowed"] is False
    assert conflict_model["write_api_required_before_apply"] == "P6-C003"
    assert conflict_model["config_delivery_required_before_user_output"] == "P6-C002"
    assert conflict_model["required_checks"] == [
        "unique_runtime_instance_id",
        "unique_listen_port_per_instance",
        "non_overlapping_vpn_cidr",
        "unique_interface_name",
        "endpoint_pair_review",
        "dns_ipv6_policy_review",
    ]
    assert conflict_model["safe_outputs"] == [
        "conflict_report",
        "operator_notes",
        "blocked_gate_summary",
    ]
    assert "runtime_config_write" in conflict_model["blocked_outputs"]
    assert "firewall_change" in conflict_model["blocked_outputs"]
    assert report["productization_boundary"]["commercial_access"]["status"] == (
        "manual_approval_boundary_ready"
    )
    assert (
        report["productization_boundary"]["commercial_access"][
            "payment_processor_enabled"
        ]
        is False
    )
    assert (
        report["productization_boundary"]["commercial_access"][
            "automatic_entitlement_on_payment"
        ]
        is False
    )
    assert report["productization_boundary"]["config_delivery_link_boundary"][
        "status"
    ] == "tokenized_link_boundary_ready"
    assert (
        report["productization_boundary"]["config_delivery_link_boundary"][
            "short_link_runtime_enabled"
        ]
        is False
    )
    assert (
        report["productization_boundary"]["config_delivery_link_boundary"][
            "token_model"
        ]["storage"]
        == "hash_at_rest_only"
    )
    assert report["productization_boundary"]["commercial_entitlement_audit"][
        "status"
    ] == "entitlement_audit_boundary_ready"
    assert (
        report["productization_boundary"]["commercial_entitlement_audit"][
            "automatic_activation_enabled"
        ]
        is False
    )
    assert (
        report["productization_boundary"]["commercial_entitlement_audit"][
            "config_delivery_decoupled"
        ]
        is True
    )
    assert report["fresh_install_wizard_boundary"]["status"] == (
        "fresh_install_wizard_ready"
    )
    assert report["fresh_install_wizard_boundary"]["mode"] == "local_only_dry_run"
    assert (
        report["fresh_install_wizard_boundary"]["safety"][
            "live_vps_commands_enabled"
        ]
        is False
    )
    assert (
        report["fresh_install_wizard_boundary"]["safety"][
            "destructive_cleanup_enabled"
        ]
        is False
    )
    assert report["fresh_install_wizard_boundary"]["docs"]["runbook"] == (
        "docs/FRESH_INSTALL_WIZARD.ru.md"
    )
    assert report["public_docs_api_taxonomy_boundary"]["status"] == (
        "public_docs_api_taxonomy_ready"
    )
    assert report["public_docs_api_taxonomy_boundary"]["publication_enabled"] is False
    assert report["public_docs_api_taxonomy_boundary"]["public_api_exposed"] is False
    assert report["public_docs_api_taxonomy_boundary"]["docs"]["taxonomy_doc"] == (
        "docs/PUBLIC_DOCS_API_TAXONOMY.ru.md"
    )
    assert report["destructive_cleanup_gate_checklist"]["status"] == (
        "destructive_cleanup_checklist_ready"
    )
    assert report["destructive_cleanup_gate_checklist"]["mode"] == "checklist_only"
    assert (
        report["destructive_cleanup_gate_checklist"][
            "destructive_execution_enabled"
        ]
        is False
    )
    assert report["destructive_cleanup_gate_checklist"]["docs"]["checklist_doc"] == (
        "docs/DESTRUCTIVE_CLEANUP_GATE_CHECKLIST.ru.md"
    )
    assert report["productization_boundary"]["bot_runtime_split"]["status"] == (
        "separate_bot_boundary_ready"
    )
    assert (
        report["productization_boundary"]["bot_runtime_split"]["support_bot"][
            "requires_separate_token"
        ]
        is True
    )
    assert (
        report["productization_boundary"]["bot_runtime_split"]["news_bot"][
            "may_touch_user_devices"
        ]
        is False
    )
    assert report["productization_boundary"]["telegram_profile_icon_apply"][
        "status"
    ] == "identity_mutation_gate_ready"
    assert report["productization_boundary"]["telegram_profile_icon_apply"][
        "telegram_api_enabled"
    ] is False
    assert report["productization_boundary"]["telegram_profile_icon_apply"][
        "codex_apply_allowed"
    ] is False
    assert report["privacy_status_boundary"]["status"] == "aggregate_privacy_boundary_ready"
    assert report["privacy_status_boundary"]["health_status_scheduler"]["status"] == (
        "scheduler_contract_ready"
    )
    assert (
        report["privacy_status_boundary"]["health_status_scheduler"][
            "live_probes_enabled"
        ]
        is False
    )
    assert report["privacy_status_boundary"]["admin_analytics"]["status"] == (
        "aggregate_only_analytics_ready"
    )
    assert (
        report["privacy_status_boundary"]["admin_analytics"][
            "per_peer_breakdown_enabled"
        ]
        is False
    )
    assert report["reconciliation_release_boundary"]["status"] == (
        "reconciliation_release_boundary_ready"
    )
    assert report["reconciliation_release_boundary"][
        "attach_existing_server_reconciliation"
    ]["status"] == "report_only_plan_ready"
    assert (
        report["reconciliation_release_boundary"][
            "attach_existing_server_reconciliation"
        ]["live_reconciliation_enabled"]
        is False
    )
    assert report["reconciliation_release_boundary"]["release_checklist"][
        "status"
    ] == "release_checklist_ready"
    assert report["reconciliation_release_boundary"]["release_checklist"][
        "default_release_action"
    ] == "planning_only"
    assert report["telemetry_retention_policy"]["status"] == (
        "telemetry_retention_policy_ready"
    )
    assert report["telemetry_retention_policy"]["aggregate_retention"][
        "raw_export_enabled"
    ] is False
    assert report["telemetry_retention_policy"]["upstream_refresh_incorporation"][
        "default_action"
    ] == "candidate_rows_only"
    assert "new live peer apply/revoke without separate operator confirmation" in report["blocked_lanes"]
    assert "/api/clients write CRUD" in report["blocked_lanes"]
    assert "additional protocol managers without capability registry" in report["blocked_lanes"]
    assert "payment processor integration without named gate" in report["blocked_lanes"]
    assert "support/news bot runtime without separate token gate" in report["blocked_lanes"]
    assert "Telegram profile icon mutation without P6-I005 gate" in report["blocked_lanes"]
    assert "live health/status polling without P6-M002 gate" in report["blocked_lanes"]
    assert "per-peer or per-user analytics without P6-N002 gate" in report["blocked_lanes"]
    assert "attach-existing-server reconciliation apply without P6-M003 gate" in report["blocked_lanes"]
    assert "release/package/public launch without P6-S001 checklist gates" in report["blocked_lanes"]
    assert "raw telemetry export without P6-N004 retention/redaction gate" in report["blocked_lanes"]
    assert "upstream refresh live actions without P6-S002 incorporation gate" in report["blocked_lanes"]
    assert "short tokenized config links require P6-C002 live/config delivery gate" in report["blocked_lanes"]
    assert "automatic commercial entitlement activation without P6-I006/P6-C003 gates" in report["blocked_lanes"]
    assert "public docs/API publication without P6-C001 public exposure gate" in report["blocked_lanes"]
    assert "destructive cleanup/reinstall without P6-C007 named destructive gate" in report["blocked_lanes"]
    assert report["next_gate"] == (
        "Phase 6 default local-only queue empty; named gate required for live/public/destructive work"
    )


def test_capability_registry_multi_instance_conflict_model_is_secret_free(tmp_path: Path):
    db_path = tmp_path / "amneziya.sqlite3"
    conn = connect(db_path)
    try:
        initialize_schema(conn)
        repo = Repository(conn)

        model_text = repr(
            build_integration_status(repo)["capability_registry"][
                "multi_instance_conflict_model"
            ]
        )
    finally:
        conn.close()

    for marker in FORBIDDEN_MARKERS + ["10.8.", "endpoint_host", "PrivateKey"]:
        assert marker not in model_text


def test_build_integration_status_contains_no_secret_or_command_markers(tmp_path: Path):
    db_path = tmp_path / "amneziya.sqlite3"
    conn = connect(db_path)
    try:
        initialize_schema(conn)
        repo = Repository(conn)
        _seed_server(repo)

        report_text = repr(build_integration_status(repo))
    finally:
        conn.close()

    for marker in FORBIDDEN_MARKERS:
        assert marker not in report_text


def test_controlled_prod_runbook_reference_exists(tmp_path: Path):
    db_path = tmp_path / "amneziya.sqlite3"
    conn = connect(db_path)
    try:
        initialize_schema(conn)
        repo = Repository(conn)
        _seed_server(repo)

        report = build_integration_status(repo)
    finally:
        conn.close()

    runbook_path = Path(report["controlled_prod_readiness"]["runbook"])
    assert runbook_path.exists()


def _seed_server(repo: Repository) -> None:
    repo.upsert_server_config(
        name="local",
        host="127.0.0.1",
        ssh_port=22,
        endpoint_host="127.0.0.1",
        vpn_port=51820,
        vpn_network_cidr="10.8.1.0/24",
        server_address="10.8.1.1/24",
        server_public_key="public-key",
        runtime="docker",
        firewall="none",
        max_devices=100,
    )


def _expected_git_head() -> str:
    result = subprocess.run(
        ["git", "rev-parse", "--short", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()
